package com.cekic.client;

import com.cekic.client.gui.CekicScreen;
import com.cekic.client.module.Module;
import com.cekic.client.module.ModuleManager;
import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CekicClient implements ClientModInitializer {
    public static final String NAME = "1.20.1 Çekiç Client";

    private static final long DOUBLE_PRESS_MS = 350;

    private boolean shiftWasDown;
    private long lastShiftPress;
    private long lastFrameNanos = System.nanoTime();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        WorldRenderEvents.START.register(context -> onFrame(context.tickDelta()));

        // Klavyesi olmayan cihazlar (mobil) için: sohbete /cekic yazınca menü açılır.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("cekic").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new CekicScreen()));
                    return Command.SINGLE_SUCCESS;
                })));
    }

    private void onTick(MinecraftClient mc) {
        if (mc.getWindow() != null) {
            boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (down && !shiftWasDown) {
                long now = System.currentTimeMillis();
                if (now - lastShiftPress <= DOUBLE_PRESS_MS) {
                    lastShiftPress = 0;
                    toggleGui(mc);
                } else {
                    lastShiftPress = now;
                }
            }
            shiftWasDown = down;
        }

        if (mc.player == null || mc.world == null) return;
        for (Module module : ModuleManager.all()) {
            module.onTick(mc);
        }
    }

    private void onFrame(float tickDelta) {
        long now = System.nanoTime();
        float dt = (now - lastFrameNanos) / 1_000_000_000f;
        lastFrameNanos = now;
        dt = Math.max(0.001f, Math.min(0.1f, dt));

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (Module module : ModuleManager.all()) {
            module.onRender(mc, tickDelta, dt);
        }
    }

    private void toggleGui(MinecraftClient mc) {
        if (mc.currentScreen instanceof CekicScreen) {
            mc.setScreen(null);
        } else if (mc.currentScreen == null) {
            mc.setScreen(new CekicScreen());
        }
    }
}
