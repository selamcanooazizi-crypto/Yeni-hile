package com.cekic.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * En yakın oyuncunun kafasına odaklanır ve havada da takip eder
 * (hedefin hareket yönünü öngörerek).
 */
public class AimAssist extends Module {
    private static final double RANGE = 6.0;
    private static final double ELYTRA_RANGE = 30.0;
    private static final float SPEED = 14.0f;             // yumuşatma hızı
    private static final float MAX_TURN_PER_SECOND = 720f; // saniyede en fazla dönüş (derece)
    private static final double LEAD_TICKS = 1.5;          // hareket öngörüsü

    public AimAssist() {
        super("Aim Assist");
    }

    @Override
    public boolean isRunning() {
        return isEnabled() || ModuleManager.ELYTRA_TARGET.isAttacking();
    }

    @Override
    public void onRender(MinecraftClient mc, float tickDelta, float dt) {
        ClientPlayerEntity self = mc.player;
        if (!isRunning() || self == null || mc.world == null || mc.currentScreen != null) return;

        double range = ModuleManager.ELYTRA_TARGET.isAttacking() ? ELYTRA_RANGE : RANGE;
        PlayerEntity target = findTarget(mc, self, range);
        if (target == null) return;

        Vec3d eye = self.getCameraPosVec(tickDelta);
        Vec3d head = target.getLerpedPos(tickDelta).add(0, target.getEyeHeight(target.getPose()), 0);

        // Hedef hareket ediyorsa (havada uçarken dahil) biraz önünü hedefle.
        Vec3d motion = new Vec3d(target.getX() - target.prevX,
                target.getY() - target.prevY,
                target.getZ() - target.prevZ);
        head = head.add(motion.multiply(LEAD_TICKS));

        double dx = head.x - eye.x;
        double dy = head.y - eye.y;
        double dz = head.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);

        float wantYaw = (float) (Math.toDegrees(Math.atan2(dz, dx))) - 90.0f;
        float wantPitch = (float) (-Math.toDegrees(Math.atan2(dy, flat)));

        float factor = 1.0f - (float) Math.exp(-SPEED * dt);
        float maxTurn = MAX_TURN_PER_SECOND * dt;

        float dYaw = MathHelper.wrapDegrees(wantYaw - self.getYaw()) * factor;
        float dPitch = (wantPitch - self.getPitch()) * factor;
        dYaw = MathHelper.clamp(dYaw, -maxTurn, maxTurn);
        dPitch = MathHelper.clamp(dPitch, -maxTurn, maxTurn);

        self.setYaw(self.getYaw() + dYaw);
        self.setPitch(MathHelper.clamp(self.getPitch() + dPitch, -90.0f, 90.0f));
    }

    private PlayerEntity findTarget(MinecraftClient mc, ClientPlayerEntity self, double range) {
        PlayerEntity best = null;
        double bestDistSq = range * range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == self || !p.isAlive() || p.isSpectator()) continue;
            double d = self.squaredDistanceTo(p);
            if (d > bestDistSq) continue;
            if (!self.canSee(p)) continue; // duvarın arkasındakini hedefleme
            best = p;
            bestDistSq = d;
        }
        return best;
    }
}
