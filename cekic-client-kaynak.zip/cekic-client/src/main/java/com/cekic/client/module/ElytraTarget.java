package com.cekic.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

/**
 * Elytra ile uçarken çalışır:
 *  1) ayarlanan gecikme (delay) kadar bekler,
 *  2) envanterden havai fişeği eline alır (ve kullanır),
 *  3) 1. slota geçer,
 *  4) Trigger Bot + Aim Assist devreye girip hedefe vurur.
 */
public class ElytraTarget extends Module {
    private enum State { IDLE, WAIT, GRAB, USE, BACK, ATTACK }

    private static final int FIRST_SLOT = 0;   // 1. slot
    private static final int SWAP_SLOT = 8;    // fişek ana envanterdeyse buraya getirilir (9. slot)

    private int delayMs = 500;
    private boolean useRocket = true;

    private State state = State.IDLE;
    private int timer;

    public ElytraTarget() {
        super("Elytra Target");
    }

    public int getDelayMs() {
        return delayMs;
    }

    public void setDelayMs(int ms) {
        this.delayMs = Math.max(0, Math.min(5000, ms));
    }

    public boolean isUseRocket() {
        return useRocket;
    }

    public void setUseRocket(boolean useRocket) {
        this.useRocket = useRocket;
    }

    /** Fişek + slot hazırlığı bitti, Trigger Bot ve Aim Assist çalışmalı mı? */
    public boolean isAttacking() {
        return isEnabled() && state == State.ATTACK;
    }

    @Override
    protected void onEnable() {
        state = State.IDLE;
    }

    @Override
    protected void onDisable() {
        state = State.IDLE;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!isEnabled()) return;
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.interactionManager == null) return;

        // Sadece elytra ile uçarken çalışır; yere inince başa döner.
        if (!player.isFallFlying()) {
            state = State.IDLE;
            return;
        }

        switch (state) {
            case IDLE -> {
                timer = (delayMs + 49) / 50; // ms -> tick
                state = State.WAIT;
            }
            case WAIT -> {
                if (timer <= 0) {
                    state = State.GRAB;
                } else {
                    timer--;
                }
            }
            case GRAB -> {
                int slot = useRocket ? prepareRocket(mc, player) : -1;
                if (slot >= 0) {
                    player.getInventory().selectedSlot = slot;
                    timer = 1;
                    state = State.USE;
                } else {
                    state = State.BACK;
                    timer = 0;
                }
            }
            case USE -> {
                if (timer > 0) {
                    timer--;
                } else {
                    mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
                    timer = 2;
                    state = State.BACK;
                }
            }
            case BACK -> {
                if (timer > 0) {
                    timer--;
                } else {
                    player.getInventory().selectedSlot = FIRST_SLOT;
                    state = State.ATTACK;
                }
            }
            case ATTACK -> {
                // Trigger Bot ve Aim Assist isAttacking() üzerinden çalışıyor.
            }
        }
    }

    /** Fişeğin bulunduğu hotbar slotunu döndürür; ana envanterdeyse hotbar'a getirir. Yoksa -1. */
    private int prepareRocket(MinecraftClient mc, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();

        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) return i;
        }
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                mc.interactionManager.clickSlot(player.playerScreenHandler.syncId, i, SWAP_SLOT,
                        SlotActionType.SWAP, player);
                return SWAP_SLOT;
            }
        }
        return -1;
    }
}
