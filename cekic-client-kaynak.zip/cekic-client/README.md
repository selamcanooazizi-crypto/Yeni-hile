# 1.20.1 Çekiç Client

Fabric 1.20.1 için client modu.

## Kullanım
- Oyunda **Sağ Shift'e iki kez hızlıca bas** → menü açılır/kapanır.
- Klavyesi olmayan mobil cihazlarda sohbete `/cekic` yaz → menü açılır.
- Modüller: **Trigger Bot**, **Aim Assist**, **Elytra Target** (Delay ayarı menüde).

## Kurulum (PC ve mobil launcher)
Gerekenler: Minecraft **1.20.1**, **Fabric Loader**, **Fabric API 0.92.x**.
Jar'ı `mods` klasörüne at.
- PC: `.minecraft/mods`
- Mobil (PojavLauncher / Zalith / FCL): profilin oyun dizinindeki `mods` klasörü.

## Jar nasıl derlenir
**Bilgisayarda:** JDK 17 kurulu olsun, bu klasörde `gradlew build` (Windows) veya `./gradlew build`
çalıştır. Jar: `build/libs/cekic-client-1.0.0.jar`

**Bilgisayar yoksa (GitHub ile):** Projeyi bir GitHub deposuna yükle → **Actions** sekmesi →
"Jar derle" → çalışma bitince **Artifacts** altından `cekic-client-jar` indir.
